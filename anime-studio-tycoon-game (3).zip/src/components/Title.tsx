import { useEffect, useState } from "react";
import { Play, Zap, Trophy, ChevronLeft, Check, Sparkles, Dices } from "lucide-react";
import { Btn } from "../fx/fx";
import { sfx, primeAudio } from "../engine/audio";
import { getScores, type ScoreEntry } from "../engine/storage";
import { PROTAGONISTS, SHOWRUNNERS, randomTitle, formatNum } from "../engine/data";
import { cn } from "../utils/cn";

/* ----------------------------------------------------------- score table */
export function HighScoreTable({ highlight }: { highlight?: number }) {
  const [scores] = useState<ScoreEntry[]>(() => getScores());
  if (!scores.length)
    return (
      <div className="text-center text-sm text-paper/50 py-8 font-jp">
        No legends yet. まだ誰もいない。
      </div>
    );
  return (
    <div className="space-y-1.5">
      {scores.map((s, i) => (
        <div
          key={s.date + i}
          className={cn(
            "flex items-center gap-3 rounded-xl border px-3 py-2 text-sm anim-up",
            i === highlight
              ? "border-gold/70 bg-gold/10 shadow-[0_0_20px_rgba(255,209,102,.25)]"
              : "border-line bg-panel2/60"
          )}
          style={{ animationDelay: `${i * 60}ms` }}
        >
          <span
            className={cn(
              "font-display font-extrabold w-7 text-center",
              i === 0 ? "text-gold" : i === 1 ? "text-paper" : i === 2 ? "text-[#cd8b5a]" : "text-paper/40"
            )}
          >
            {i + 1}
          </span>
          <div className="flex-1 min-w-0">
            <div className="font-bold truncate">{s.name}</div>
            <div className="text-[11px] text-paper/50">
              Y{s.year} · {s.shows} shows · {formatNum(s.fans)} fans {s.victory ? "· LEGEND" : ""}
            </div>
          </div>
          <div className="font-display font-extrabold text-gold">{s.score.toLocaleString()}</div>
        </div>
      ))}
    </div>
  );
}

/* ----------------------------------------------------------------- title */
export default function Title({
  onStart,
}: {
  onStart: (studio: string, showrunner: string) => void;
}) {
  const [view, setView] = useState<"menu" | "setup" | "scores">("menu");
  const [studio, setStudio] = useState("Studio Kirameki");
  const [runner, setRunner] = useState<"steady" | "vision">("steady");

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "Enter") {
        primeAudio();
        if (view === "menu") {
          sfx.select();
          setView("setup");
        } else if (view === "setup") {
          sfx.select();
          onStart(studio.trim() || "Studio Kirameki", runner);
        }
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [view, studio, runner, onStart]);

  return (
    <div className="relative h-full w-full overflow-hidden bg-ink gridlines">
      <div className="absolute inset-0 speedlines opacity-60" />
      <div className="absolute inset-0 screentone opacity-60" />
      <div className="absolute -top-40 left-1/2 h-[480px] w-[820px] -translate-x-1/2 rounded-full bg-neon/15 blur-[120px]" />
      <div className="absolute -bottom-48 -right-24 h-[420px] w-[420px] rounded-full bg-cyanx/10 blur-[100px]" />
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {Array.from({ length: 12 }).map((_, i) => (
          <span
            key={i}
            className="petal"
            style={{
              left: `${(i * 83) % 100}%`,
              animationDelay: `${i * 1.4}s`,
              animationDuration: `${9 + (i % 5) * 2.2}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 mx-auto flex h-full max-w-5xl flex-col items-center justify-between px-4 py-6 md:py-8">
        {/* logo */}
        <div className="text-center anim-up">
          <div className="font-jp text-neon/90 text-xs md:text-sm tracking-[0.5em] mb-1">
            アニメスタジオ・タイクーン
          </div>
          <h1 className="font-display font-extrabold leading-[0.9] text-[15vw] md:text-[7.5rem] tracking-tight">
            <span className="text-paper drop-shadow-[0_4px_0_rgba(255,77,141,.55)]">KIRA</span>
            <span className="text-neon drop-shadow-[0_4px_0_rgba(59,225,255,.45)]">MEKI</span>
          </h1>
          <div className="mt-2 inline-flex items-center gap-2 ink-chip px-4 py-1.5 text-[11px] md:text-xs font-bold tracking-[0.3em] text-paper/80">
            <Sparkles size={13} className="text-gold" />
            ANIME STUDIO TYCOON
            <Sparkles size={13} className="text-gold" />
          </div>
          <div className="mt-1.5 text-[10px] font-bold tracking-[0.2em] text-paper/40">
            SIX YEARS · £90,000 · ONE BEDROOM STUDIO
          </div>
        </div>

        {/* body */}
        <div className="w-full max-w-2xl anim-up" style={{ animationDelay: "120ms" }}>
          {view === "menu" && (
            <div className="flex flex-col items-center gap-3">
              <Btn big variant="primary" className="w-72 anim-ring" onClick={() => setView("setup")}>
                <Play size={20} /> FOUND YOUR STUDIO
              </Btn>
              <Btn
                big
                variant="cyan"
                className="w-72"
                onClick={() => onStart("Studio Kirameki", Math.random() < 0.5 ? "steady" : "vision")}
              >
                <Zap size={20} /> QUICK START
              </Btn>
              <Btn big variant="ghost" className="w-72" onClick={() => setView("scores")}>
                <Trophy size={20} className="text-gold" /> HALL OF FAME
              </Btn>
              <div className="mt-2 max-w-xs text-center font-jp text-[11px] leading-relaxed text-paper/40">
                Take contracts, plan shows, pop the point bubbles your staff make.
                <br />
                ENTER begin · tap or keys 1-7 · SPACE grab · ESC pause
              </div>
            </div>
          )}

          {view === "scores" && (
            <div className="ink-card p-4 md:p-5">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="font-display text-xl font-extrabold text-gold flex items-center gap-2">
                  <Trophy size={18} /> HALL OF FAME
                </h2>
                <Btn variant="ghost" onClick={() => setView("menu")}>
                  <ChevronLeft size={16} /> Back
                </Btn>
              </div>
              <HighScoreTable />
            </div>
          )}

          {view === "setup" && (
            <div className="ink-card p-4 md:p-6 space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-xl md:text-2xl font-extrabold">REGISTER YOUR STUDIO</h2>
                <Btn variant="ghost" onClick={() => setView("menu")}>
                  <ChevronLeft size={16} /> Back
                </Btn>
              </div>

              <div>
                <label className="text-xs font-bold tracking-widest text-paper/50">STUDIO NAME</label>
                <div className="mt-1.5 flex gap-2">
                  <input
                    value={studio}
                    onChange={(e) => setStudio(e.target.value.slice(0, 26))}
                    className="ink-input flex-1 px-4 py-3 text-base font-bold"
                    placeholder="Studio Kirameki"
                  />
                  <Btn
                    variant="ghost"
                    onClick={() => setStudio(`Studio ${randomTitle().split(" ")[0]}`)}
                    aria-label="Random name"
                  >
                    <Dices size={18} />
                  </Btn>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold tracking-widest text-paper/50">
                  CHOOSE YOUR SHOWRUNNER — 原作者
                </label>
                <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {SHOWRUNNERS.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => {
                        sfx.select();
                        setRunner(s.id);
                      }}
                      className={cn(
                        "btn-press group relative overflow-hidden rounded-2xl border text-left ink-card",
                        runner === s.id
                          ? "border-neon shadow-[0_0_30px_rgba(255,77,141,.35)]"
                          : "border-line opacity-80 hover:opacity-100"
                      )}
                    >
                      <div className="flex items-center gap-3 p-3">
                        <img
                          src={s.img}
                          alt={s.name}
                          className="h-20 w-20 rounded-xl object-cover border border-line"
                        />
                        <div className="min-w-0">
                          <div className="font-display font-extrabold leading-tight">{s.name}</div>
                          <div className="text-[11px] font-bold text-cyanx">{s.title}</div>
                          <div className="mt-1 text-[11px] leading-snug text-paper/60">{s.perk}</div>
                        </div>
                      </div>
                      {runner === s.id && (
                        <div className="absolute right-2 top-2 rounded-full bg-neon p-1 text-white">
                          <Check size={13} />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <Btn
                big
                variant="primary"
                className="w-full"
                onClick={() => onStart(studio.trim() || "Studio Kirameki", runner)}
              >
                <Zap size={20} /> OPEN FOR BUSINESS — 開業!
              </Btn>
            </div>
          )}
        </div>

        {/* marquee */}
        <div className="w-full overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_8%,black_92%,transparent)]">
          <div className="flex w-max gap-3 pr-3" style={{ animation: "marquee 36s linear infinite" }}>
            {[...PROTAGONISTS, ...PROTAGONISTS].map((p, i) => (
              <div key={i} className="ink-card flex items-center gap-2.5 p-2 pr-4">
                <img src={p.img} alt={p.name} className="h-11 w-11 rounded-lg object-cover" />
                <div>
                  <div className="text-xs font-extrabold font-display">{p.name}</div>
                  <div className="text-[10px] text-paper/50">{p.archetype}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
