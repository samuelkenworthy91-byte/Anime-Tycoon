import {
  Flame,
  Flower2,
  Bot,
  Sparkles,
  Coffee,
  Ghost,
  Heart,
  Trophy,
  Cpu,
  Sword,
  Mic2,
  Eye,
  type LucideIcon,
} from "lucide-react";

/* ------------------------------------------------------------------ types */
export type GenreId =
  | "shonen"
  | "shojo"
  | "mecha"
  | "isekai"
  | "slice"
  | "horror"
  | "romance"
  | "sports"
  | "cyber"
  | "fantasy"
  | "idol"
  | "mystery";

export type MediumId = "tv" | "movie" | "ona";
export type BudgetId = "indie" | "standard" | "blockbuster";
export type SlotId = "midnight" | "evening" | "prime" | "stream";
export type AudienceId = "kids" | "teens" | "adults" | "family";
export type StaffRole = "writer" | "animator" | "composer";
export type PointType = "story" | "art" | "sound";

export interface Genre {
  id: GenreId;
  label: string;
  jp: string;
  color: string;
  icon: LucideIcon;
  desc: string;
  /** ideal slider value per phase (0..100, % toward first aspect) */
  ideal: [number, number, number];
  /** target mix of Story / Art / Sound points (sums to 1) */
  ratio: [number, number, number];
  /** research data cost to unlock (0 = available from the start) */
  rd: number;
}

export interface Staff {
  id: string;
  name: string;
  role: StaffRole;
  /** per-discipline skill 10..99 */
  story: number;
  art: number;
  sound: number;
  level: number;
  salary: number; // per week
  cost: number; // signing fee
  stamina: number; // 0..100, drains with work
}

export interface Protagonist {
  id: string;
  name: string;
  archetype: string;
  img: string;
  tag: string;
  aff: GenreId[];
}

export interface Arc {
  id: string;
  name: string;
  jp: string;
  cost: number;
  q: number;
  f: number;
  desc: string;
  syn?: GenreId[];
  synQ?: number;
  synF?: number;
  franchiseOnly?: boolean;
}

export interface Draft {
  title: string;
  medium: MediumId;
  budget: BudgetId;
  slot: SlotId;
  genres: GenreId[];
  audience: AudienceId;
  protag: string;
  protagName: string;
  arcs: string[];
  sliders: [number, number, number];
  franchiseKey?: string;
  season: number;
}

/* ---------------------------------------------------------------- genres */
export const GENRES: Genre[] = [
  { id: "shonen", label: "Shonen", jp: "少年", color: "#ff7a3d", icon: Flame, desc: "Hot-blooded battles & friendship.", ideal: [70, 68, 55], ratio: [0.3, 0.45, 0.25], rd: 0 },
  { id: "shojo", label: "Shojo", jp: "少女", color: "#ff8fc7", icon: Flower2, desc: "Feelings first, sparkles mandatory.", ideal: [30, 45, 62], ratio: [0.42, 0.3, 0.28], rd: 0 },
  { id: "slice", label: "Slice of Life", jp: "日常", color: "#ffd166", icon: Coffee, desc: "Nothing happens, beautifully.", ideal: [30, 36, 55], ratio: [0.45, 0.25, 0.3], rd: 0 },
  { id: "fantasy", label: "Fantasy", jp: "ファンタジー", color: "#c084fc", icon: Sword, desc: "Guilds, magic, long walks.", ideal: [60, 60, 50], ratio: [0.36, 0.4, 0.24], rd: 0 },
  { id: "romance", label: "Romance", jp: "恋愛", color: "#ff5e7a", icon: Heart, desc: "Will they? They won't. They will.", ideal: [26, 46, 56], ratio: [0.46, 0.24, 0.3], rd: 14 },
  { id: "sports", label: "Sports", jp: "スポーツ", color: "#fbbf24", icon: Trophy, desc: "Sweat, tears, tournament arcs.", ideal: [72, 75, 55], ratio: [0.26, 0.5, 0.24], rd: 18 },
  { id: "mecha", label: "Mecha", jp: "メカ", color: "#7af0ff", icon: Bot, desc: "Giant robots, bigger budgets.", ideal: [60, 72, 48], ratio: [0.22, 0.54, 0.24], rd: 22 },
  { id: "isekai", label: "Isekai", jp: "異世界", color: "#a78bfa", icon: Sparkles, desc: "Truck-kun strikes again.", ideal: [66, 58, 45], ratio: [0.38, 0.38, 0.24], rd: 24 },
  { id: "horror", label: "Horror", jp: "ホラー", color: "#a3e635", icon: Ghost, desc: "Don't watch alone at 2AM.", ideal: [66, 40, 72], ratio: [0.32, 0.3, 0.38], rd: 26 },
  { id: "idol", label: "Idol", jp: "アイドル", color: "#f472b6", icon: Mic2, desc: "Center position or nothing.", ideal: [55, 56, 82], ratio: [0.24, 0.32, 0.44], rd: 30 },
  { id: "mystery", label: "Mystery", jp: "ミステリー", color: "#94a3b8", icon: Eye, desc: "The butler never did it.", ideal: [72, 40, 50], ratio: [0.5, 0.24, 0.26], rd: 32 },
  { id: "cyber", label: "Cyberpunk", jp: "サイバー", color: "#22d3ee", icon: Cpu, desc: "Neon rain and broken AIs.", ideal: [58, 66, 76], ratio: [0.3, 0.36, 0.34], rd: 36 },
];

export const GENRE = (id: GenreId) => GENRES.find((g) => g.id === id)!;

/* genre-pair synergy matrix (GDT-style "great combos") */
const pair = (a: GenreId, b: GenreId) => [a, b].sort().join("|");
export const COMBO: Record<string, number> = {
  [pair("shonen", "sports")]: 1.3,
  [pair("shonen", "fantasy")]: 1.22,
  [pair("shonen", "mecha")]: 1.2,
  [pair("isekai", "fantasy")]: 1.25,
  [pair("isekai", "shonen")]: 1.16,
  [pair("mecha", "cyber")]: 1.25,
  [pair("shojo", "romance")]: 1.25,
  [pair("romance", "slice")]: 1.2,
  [pair("horror", "mystery")]: 1.25,
  [pair("cyber", "mystery")]: 1.2,
  [pair("idol", "slice")]: 1.15,
  [pair("fantasy", "shojo")]: 1.12,
  [pair("sports", "slice")]: 1.1,
  [pair("horror", "cyber")]: 1.1,
  [pair("idol", "shonen")]: 1.08,
  [pair("horror", "idol")]: 0.68,
  [pair("cyber", "shojo")]: 0.8,
  [pair("mecha", "slice")]: 0.8,
  [pair("horror", "sports")]: 0.8,
  [pair("sports", "mystery")]: 0.85,
  [pair("isekai", "romance")]: 0.88,
  [pair("mecha", "shojo")]: 0.9,
};
export const comboKey = (genres: GenreId[]) => [...genres].sort().join("|");
export const comboMult = (genres: GenreId[]) =>
  genres.length === 2 ? COMBO[comboKey(genres)] ?? 1 : 1;
export const comboLabel = (genres: GenreId[]) => {
  if (genres.length < 2) return { label: "Single genre — focused", cls: "text-cyanx", mult: 1 };
  const m = comboMult(genres);
  if (m >= 1.2) return { label: "GREAT COMBO!", cls: "text-gold", mult: m };
  if (m >= 1.08) return { label: "Good synergy", cls: "text-mint", mult: m };
  if (m >= 0.95) return { label: "Safe pairing", cls: "text-paper/70", mult: m };
  return { label: "RISKY MIX…", cls: "text-neon", mult: m };
};
/** combo level 0-5 raises quality the more you refine a pairing (Game Dev Story style) */
export const comboLevelBonus = (lv: number) => 1 + Math.min(5, lv) * 0.035;

/* ---------------------------------------------------------------- economy */
export const MEDIUMS: Record<MediumId, { label: string; jp: string; desc: string; costMult: number; reach: number; weeks: number; rd: number }> = {
  tv: { label: "TV Series", jp: "テレビ", desc: "12 episodes. The classic grind.", costMult: 1, reach: 1, weeks: 0, rd: 0 },
  ona: { label: "ONA Shorts", jp: "ネット", desc: "Cheap net mini-series for the fans.", costMult: 0.62, reach: 0.78, weeks: -3, rd: 0 },
  movie: { label: "Theatrical Film", jp: "映画", desc: "Big screen, big risk, big reward.", costMult: 1.7, reach: 1.5, weeks: 4, rd: 40 },
};

export const BUDGETS: Record<BudgetId, { label: string; cost: number; scope: number; desc: string; heat: number }> = {
  indie: { label: "Ink & Paper Indie", cost: 40_000, scope: 0.85, desc: "Tiny team, huge heart.", heat: 0 },
  standard: { label: "Standard Production", cost: 120_000, scope: 1.0, desc: "Full pipeline, sane deadlines.", heat: 0.15 },
  blockbuster: { label: "Blockbuster Line", cost: 320_000, scope: 1.32, desc: "Insane sakuga. Insane invoices.", heat: 0.3 },
};

export const SLOTS: Record<SlotId, { label: string; jp: string; cost: number; reach: number; best: GenreId[]; desc: string }> = {
  midnight: { label: "Midnight Otaku Slot", jp: "深夜", cost: 6_000, reach: 0.78, best: ["horror", "mystery", "cyber", "slice"], desc: "Cheap airtime for devoted weirdos." },
  evening: { label: "Evening Family Slot", jp: "夕方", cost: 40_000, reach: 1.15, best: ["romance", "shojo", "slice", "fantasy"], desc: "Dinner-table viewing." },
  stream: { label: "Global Streaming", jp: "配信", cost: 60_000, reach: 1.35, best: ["isekai", "fantasy", "cyber", "horror"], desc: "Day-one simulcast worldwide." },
  prime: { label: "Prime-Time Saturday", jp: "ゴールデン", cost: 110_000, reach: 1.62, best: ["shonen", "sports", "mecha", "idol"], desc: "The whole nation watches." },
};

export const AUDIENCES: Record<AudienceId, { label: string; jp: string; mult: number; fit: Partial<Record<GenreId, number>>; desc: string }> = {
  kids: { label: "Saturday Kids", jp: "子供", mult: 1.0, fit: { shonen: 1.2, sports: 1.15, idol: 1.1, mecha: 1.05, horror: 0.7, cyber: 0.8, mystery: 0.9, romance: 0.9 }, desc: "Toys sell themselves." },
  teens: { label: "Teen Fever", jp: "ティーン", mult: 1.05, fit: { shonen: 1.15, isekai: 1.15, horror: 1.05, mecha: 1.0, romance: 1.0, idol: 1.05, slice: 0.95 }, desc: "Loud, loyal, extremely online." },
  adults: { label: "Seinen Adults", jp: "大人", mult: 1.0, fit: { cyber: 1.2, mystery: 1.15, horror: 1.1, slice: 1.05, romance: 1.0, shojo: 0.95, shonen: 0.88, isekai: 0.95 }, desc: "Discerning tastes, deep wallets." },
  family: { label: "All Ages", jp: "みんな", mult: 1.12, fit: { idol: 1.15, sports: 1.1, shonen: 1.05, fantasy: 1.05, slice: 1.05, horror: 0.85, cyber: 0.9 }, desc: "Hard to please everyone." },
};

/* ---------------------------------------------------------------- offices */
export interface Office {
  id: number;
  name: string;
  jp: string;
  maxStaff: number;
  rent: number; // weekly
  cost: number; // relocation fee
  desks: number;
  blurb: string;
}
export const OFFICES: Office[] = [
  { id: 0, name: "Bedroom Studio", jp: "四畳半", maxStaff: 2, rent: 400, cost: 0, desks: 3, blurb: "A futon, a tablet and a dream." },
  { id: 1, name: "Kirameki Building", jp: "雑居ビル", maxStaff: 4, rent: 2_200, cost: 220_000, desks: 5, blurb: "Second floor above a ramen shop." },
  { id: 2, name: "Sakuga Tower", jp: "スタジオ塔", maxStaff: 6, rent: 6_500, cost: 1_100_000, desks: 7, blurb: "Glass walls. Real coffee. Legends work here." },
];

/* --------------------------------------------------------------- research */
export interface ResearchItem {
  id: string;
  name: string;
  jp: string;
  rd: number;
  desc: string;
}
export const RESEARCH: ResearchItem[] = [
  { id: "storyboard", name: "Storyboard Method", jp: "絵コンテ術", rd: 20, desc: "Bubbles linger 25% longer on the floor." },
  { id: "pipeline", name: "Digital Pipeline", jp: "デジタル化", rd: 28, desc: "+20% bubble spawn rate in every phase." },
  { id: "qa", name: "QA Department", jp: "品質管理", rd: 24, desc: "30% fewer production issues appear." },
  { id: "marketing", name: "Marketing Dept.", jp: "宣伝部", rd: 30, desc: "Unlocks the big promo campaigns." },
  { id: "merch", name: "Merch Division", jp: "物販", rd: 34, desc: "+18% revenue from every show." },
  { id: "mocap", name: "Motion Reference", jp: "作画参考", rd: 40, desc: "Art bubbles are worth +1 point." },
];

/* -------------------------------------------------------------- contracts */
export interface Contract {
  id: string;
  name: string;
  jp: string;
  type: PointType;
  target: number;
  weeks: number;
  pay: number;
  rd: number;
}
const CONTRACT_POOL: { name: string; jp: string; type: PointType }[] = [
  { name: "Light Novel Cover", jp: "挿絵", type: "art" },
  { name: "Game Cutscene", jp: "ゲーム映像", type: "art" },
  { name: "Idol MV Insert", jp: "MV", type: "sound" },
  { name: "Radio Drama CD", jp: "ドラマCD", type: "sound" },
  { name: "Manga Script Doctor", jp: "脚本協力", type: "story" },
  { name: "Web Novel Adaptation", jp: "web小説", type: "story" },
  { name: "Ad Agency Short", jp: "CM", type: "art" },
  { name: "Museum Anime Loop", jp: "展示映像", type: "art" },
  { name: "Anthology Episode", jp: "オムニバス", type: "story" },
  { name: "Theme Song Arrange", jp: "主題歌", type: "sound" },
];
let cid = 0;
export function rollContract(week: number): Contract {
  const base = CONTRACT_POOL[Math.floor(Math.random() * CONTRACT_POOL.length)];
  const scale = 1 + week / 90;
  const target = Math.round((16 + Math.random() * 26) * scale);
  const weeks = 2 + Math.floor(Math.random() * 3);
  return {
    id: `c${++cid}_${week}`,
    ...base,
    target,
    weeks,
    pay: Math.round((target * 900 + weeks * 4_000) / 500) * 500,
    rd: Math.max(2, Math.round(target / 6)),
  };
}

/* ------------------------------------------------------------------ promo */
export interface Promo {
  id: string;
  name: string;
  jp: string;
  cost: number;
  hype: number;
  desc: string;
  locked?: boolean;
}
export const PROMOS: Promo[] = [
  { id: "pv", name: "Teaser PV", jp: "予告", cost: 12_000, hype: 10, desc: "30 seconds of vibes, zero plot." },
  { id: "kv", name: "Key Visual Blitz", jp: "キービジュ", cost: 26_000, hype: 18, desc: "Station posters everywhere." },
  { id: "mag", name: "Magazine Spread", jp: "雑誌広告", cost: 48_000, hype: 26, desc: "Six glossy pages of hype." },
  { id: "stage", name: "Expo Stage Event", jp: "イベント", cost: 95_000, hype: 40, desc: "Cast on stage, fans in tears.", locked: true },
];

/* ------------------------------------------------------------ protagonists */
export const PROTAGONISTS: Protagonist[] = [
  { id: "kai", name: "Kai", archetype: "Battle Heart", img: "/img/protag-kai.jpg", tag: "Never gives up. Ever.", aff: ["shonen", "sports", "fantasy"] },
  { id: "hikari", name: "Hikari", archetype: "Prism Wish", img: "/img/protag-hikari.jpg", tag: "Transforms homework into miracles.", aff: ["shojo", "fantasy", "romance"] },
  { id: "rei", name: "Rei", archetype: "Steel Resolve", img: "/img/protag-rei.jpg", tag: "Sync rate: 400% on Mondays.", aff: ["mecha", "cyber", "mystery"] },
  { id: "sora", name: "Sora", archetype: "Skyblade", img: "/img/protag-sora.jpg", tag: "Reincarnated with max charisma.", aff: ["isekai", "fantasy", "shonen"] },
  { id: "yui", name: "Yui", archetype: "Everyday Warmth", img: "/img/protag-yui.jpg", tag: "Weaponized coziness.", aff: ["slice", "romance", "shojo"] },
  { id: "kage", name: "Kage", archetype: "Shadow Edge", img: "/img/protag-kage.jpg", tag: "Monologues in the rain.", aff: ["horror", "mystery", "cyber"] },
  { id: "airi", name: "Airi", archetype: "Center Stage", img: "/img/protag-airi.jpg", tag: "Streams at 3AM, still sparkling.", aff: ["idol", "shonen", "slice"] },
  { id: "shiro", name: "Shiro", archetype: "Keen Mind", img: "/img/protag-shiro.jpg", tag: "Solved the plot in episode 1.", aff: ["mystery", "horror", "slice"] },
];

/* ------------------------------------------------------------------- arcs */
export const ARCS: Arc[] = [
  { id: "hook", name: "Cold Open Hook", jp: "掴み", cost: 8_000, q: 4, f: 0.04, desc: "Start with a bang. Critics rewatch it." },
  { id: "lore", name: "Worldbuilding Dive", jp: "設定", cost: 15_000, q: 3, f: 0.03, syn: ["fantasy", "cyber", "mystery"], synQ: 3, desc: "Lore so deep the wiki needs editors." },
  { id: "montage", name: "Training Montage", jp: "修行", cost: 10_000, q: 2, f: 0.03, syn: ["shonen", "sports"], synQ: 3, desc: "Push-ups! Friendship! Power levels!" },
  { id: "tournament", name: "Tournament Arc", jp: "大会", cost: 26_000, q: 1, f: 0.14, syn: ["shonen", "sports"], synQ: 4, desc: "Bracket of dreams. Merch prints money." },
  { id: "beach", name: "Beach Episode", jp: "海", cost: 6_000, q: -1, f: 0.09, syn: ["romance", "slice"], synQ: 3, desc: "Pure fanservice. Critics sigh. Fans scream." },
  { id: "festival", name: "Festival Episode", jp: "祭り", cost: 11_000, q: 2, f: 0.05, syn: ["romance", "slice", "shojo"], synQ: 3, desc: "Yukata, fireworks, almost-confessions." },
  { id: "launch", name: "Mecha Launch", jp: "発進", cost: 24_000, q: 1, f: 0.05, syn: ["mecha", "cyber"], synQ: 5, desc: "90 uninterrupted seconds of launch sequence." },
  { id: "live", name: "Idol Live", jp: "ライブ", cost: 21_000, q: 1, f: 0.1, syn: ["idol"], synQ: 5, synF: 0.03, desc: "A full episode concert. Glowsticks sold separately." },
  { id: "case", name: "Phantom Case", jp: "事件", cost: 12_000, q: 3, f: 0.04, syn: ["mystery", "horror"], synQ: 4, desc: "A locked-room mystery. In space. Maybe." },
  { id: "twist", name: "Tragic Twist", jp: "衝撃", cost: 14_000, q: 5, f: 0, syn: ["horror", "mystery", "shojo"], synQ: 3, desc: "Nobody saw it coming. Nobody recovered." },
  { id: "filler", name: "Filler Saga", jp: "原作無視", cost: -10_000, q: -3, f: 0.02, desc: "Cheap padding. The manga isn't ready." },
  { id: "timeskip", name: "Timeskip Reboot", jp: "時経", cost: 14_000, q: 2, f: 0.05, syn: ["shonen", "isekai"], synQ: 2, desc: "Three years pass. Everyone's buffer now." },
  { id: "crossover", name: "Crossover Special", jp: "共演", cost: 28_000, q: 0, f: 0.12, franchiseOnly: true, desc: "Your past casts collide in one hour of chaos." },
  { id: "finale", name: "Finale Climax", jp: "最終回", cost: 20_000, q: 3, f: 0.06, desc: "Everything pays off. Better nail the landing." },
];

/* ------------------------------------------------------------------ staff */
const FIRST = ["Hana", "Yuto", "Mei", "Ren", "Sakura", "Daichi", "Aoi", "Kenji", "Mio", "Sota", "Rin", "Takeshi", "Nao", "Haru", "Yuki", "Kenta", "Asuka", "Shun", "Emi", "Taiga", "Kira", "Masa", "Noa", "Goro"];
const LAST = ["Tanaka", "Sato", "Kurosawa", "Ishikawa", "Mori", "Abe", "Fujimoto", "Okabe", "Shinohara", "Wakamatsu", "Hirasawa", "Kobayashi", "Endo", "Miura", "Tsukishima", "Araki"];

export const ROLE_LABEL: Record<StaffRole, string> = { writer: "Writer", animator: "Animator", composer: "Composer" };
export const ROLE_JP: Record<StaffRole, string> = { writer: "脚本", animator: "作画", composer: "音響" };
export const ROLE_POINT: Record<StaffRole, PointType> = { writer: "story", animator: "art", composer: "sound" };
export const POINT_LABEL: Record<PointType, string> = { story: "Story", art: "Art", sound: "Sound" };
export const POINT_COLOR: Record<PointType, string> = { story: "#ff4d8d", art: "#3be1ff", sound: "#ffd166" };

export const LEVEL_TITLES = ["Rookie", "Key Artist", "Chief", "Director", "Legend"];

let staffId = 0;
export function rollCandidate(week: number): Staff {
  const roles: StaffRole[] = ["writer", "animator", "composer"];
  const role = roles[Math.floor(Math.random() * 3)];
  const tier = Math.min(45, week * 0.16);
  const main = Math.round(34 + Math.random() * 34 + tier);
  const off = () => Math.round(12 + Math.random() * 30 + tier * 0.5);
  const s: Staff = {
    id: `s${++staffId}_${Date.now()}${Math.floor(Math.random() * 999)}`,
    name: `${FIRST[Math.floor(Math.random() * FIRST.length)]} ${LAST[Math.floor(Math.random() * LAST.length)]}`,
    role,
    story: role === "writer" ? main : off(),
    art: role === "animator" ? main : off(),
    sound: role === "composer" ? main : off(),
    level: 1,
    stamina: 100,
    salary: 0,
    cost: 0,
  };
  s.salary = Math.round((320 + main * 12) / 10) * 10;
  s.cost = Math.round((5_000 + main * 420) / 500) * 500;
  return s;
}
export const staffPoint = (s: Staff, t: PointType) => (t === "story" ? s.story : t === "art" ? s.art : s.sound);
export const staffMain = (s: Staff) => staffPoint(s, ROLE_POINT[s.role]);
export const levelUpCost = (s: Staff) => 8 + s.level * 6;

/* ------------------------------------------------------------- showrunners */
export interface Showrunner {
  id: "steady" | "vision";
  name: string;
  title: string;
  img: string;
  perk: string;
}
export const SHOWRUNNERS: Showrunner[] = [
  { id: "steady", name: "Genji Ashida", title: "The Master Animator", img: "/img/showrunner-a.jpg", perk: "Steady Hand — bubbles float 20% longer and issues are rarer." },
  { id: "vision", name: "Akari Natsume", title: "The Visionary Director", img: "/img/showrunner-b.jpg", perk: "Vision — dramatic arcs hit harder, no review below 3/10." },
];

/* --------------------------------------------------------------- reviewers */
export interface Reviewer {
  name: string;
  focus: string;
  bias: "story" | "hype" | "harsh" | "tech";
  quotes: Record<string, string[]>;
}
export const REVIEWERS: Reviewer[] = [
  {
    name: "Animage Monthly",
    focus: "writing",
    bias: "story",
    quotes: {
      masterpiece: ["A once-in-a-decade script. Frame it in the lobby.", "I wept into my storyboard. Twice."],
      hit: ["Strong writing with real emotional payload.", "The writers' room deserves a raise."],
      solid: ["Competent storytelling, a few saggy episodes.", "Solid penmanship, if a little safe."],
      mixed: ["The script trips over its own ambitions.", "Promising ideas, wobbly execution."],
      flop: ["I've read better plots on instant noodle pots.", "Were the writers tracing another show?"],
    },
  },
  {
    name: "Otaku Pulse",
    focus: "fandom",
    bias: "hype",
    quotes: {
      masterpiece: ["MY TIMELINE IS ON FIRE. ABSOLUTE CINEMA.", "Cancelled my plans. All of them. Forever."],
      hit: ["The fandom is unwell (affectionate).", "Clip it. Ship it. Stream it again."],
      solid: ["The fanbase is cautiously optimistic!", "Decent watch-party material."],
      mixed: ["The comment section is at war.", "Mid, but the memes are premium."],
      flop: ["Ratio'd by its own studio's apology post.", "The fandom has filed a restraining order."],
    },
  },
  {
    name: "The London Reel",
    focus: "industry",
    bias: "harsh",
    quotes: {
      masterpiece: ["A landmark for the medium. We eat our words gladly.", "Rare perfection from a studio on the rise."],
      hit: ["A confident work from a studio to watch.", "Commercial instincts meet genuine craft."],
      solid: ["Serviceable. The industry survives another season.", "Adequate fare for its time slot."],
      mixed: ["Ambition outpaces the production schedule.", "Shows flashes, but the seams show."],
      flop: ["A cautionary tale for production committees.", "Airtime this wasted should be studied."],
    },
  },
  {
    name: "StudioScope",
    focus: "craft",
    bias: "tech",
    quotes: {
      masterpiece: ["Sakuga so clean my screen filed for unemployment.", "The compositing alone merits the score."],
      hit: ["Animation and OST in perfect sync.", "Genuinely gorgeous key sequences."],
      solid: ["Craft is consistent, if rarely dazzling.", "Some strong cuts between the stock footage."],
      mixed: ["Off-model episodes undercut the good ones.", "The sound mix deserved better drawings."],
      flop: ["Three frames of animation. I counted.", "The slideshow was... brave."],
    },
  },
];

/* ------------------------------------------------------------------- misc */
export const SPIRITS_A = ["Neo", "Star", "Ultra", "Phantom", "Moonlight", "Cyber", "Rocket", "Crystal", "Samurai", "Midnight", "Turbo", "Ghost", "Honey", "Iron", "Velvet"];
export const SPIRITS_B = ["Wolf", "Academy", "Blade", "Parade", "Voyage", "Symphony", "Protocol", "Heartbeat", "Odyssey", "Kiss", "Delivery", "Alliance", "Club", "Zero", "Crown"];
export const SPIRITS_C = ["X", "2049", "Re", "EX", "II", "∞", "Z", "Dash"];
export function randomTitle(): string {
  const a = SPIRITS_A[Math.floor(Math.random() * SPIRITS_A.length)];
  const b = SPIRITS_B[Math.floor(Math.random() * SPIRITS_B.length)];
  const c = Math.random() < 0.4 ? ` ${SPIRITS_C[Math.floor(Math.random() * SPIRITS_C.length)]}` : "";
  return `${a} ${b}${c}`;
}

export const NEWS = [
  "Rival studio CRIMSON GEAR announces a 4-cour mecha epic…",
  "Streaming giant renews isekai anthology for 9th season.",
  "Figure scalpers crash site for beach-episode exclusive.",
  "Voice actor union wins karaoke night championship.",
  "Budget cuts hit industry: animators subsist on toast.",
  "Survey: 64% of fans can't name a single producer.",
  "Midnight slot horror anthology traumatises night owls.",
  "Kai plushies sell out in 4 minutes. Bots blamed.",
  "London Anime Expo adds a Sakuga Prize category.",
  "Manga author 'on hiatus' spotted at fishing tourney again.",
];

/* ------------------------------------------------------------------ money */
export function formatGBP(n: number): string {
  const v = Math.round(n);
  const sign = v < 0 ? "-" : "";
  return `${sign}£${Math.abs(v).toLocaleString("en-GB")}`;
}
export function formatGBPShort(n: number): string {
  const a = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (a >= 1_000_000) return `${sign}£${(a / 1_000_000).toFixed(a >= 10_000_000 ? 1 : 2)}M`;
  if (a >= 1_000) return `${sign}£${(a / 1000).toFixed(a >= 100_000 ? 0 : 1)}k`;
  return `${sign}£${Math.round(a)}`;
}
export function formatNum(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(2) + "M";
  if (n >= 10_000) return (n / 1000).toFixed(1) + "K";
  return Math.round(n).toLocaleString("en-GB");
}

/* -------------------------------------------------------------- calendar */
export const WEEKS_PER_MONTH = 4;
export const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
export const yearOfWeek = (w: number) => Math.floor(w / 48) + 1;
export const monthOfWeek = (w: number) => Math.floor((w % 48) / 4);
export const weekOfMonth = (w: number) => (w % 4) + 1;
export const dateLabel = (w: number) => `Y${yearOfWeek(w)} ${MONTHS[monthOfWeek(w)]} W${weekOfMonth(w)}`;
