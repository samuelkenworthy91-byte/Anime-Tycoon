import {
  OFFICES,
  rollCandidate,
  rollContract,
  type Contract,
  type Draft,
  type GenreId,
  type Staff,
} from "./data";
import type { ShowResult } from "./scoring";

export interface Franchise {
  baseTitle: string;
  season: number;
  lastScore: number;
  /** hall-of-fame shows may spawn sequels; a failed sequel ends the line */
  alive: boolean;
}

export interface HofEntry {
  title: string;
  score: number;
  genres: GenreId[];
  protag: string;
  week: number;
}

export interface RunState {
  studio: string;
  showrunner: string;
  cash: number;
  fans: number;
  rd: number; // research data
  week: number;
  officeLevel: number;
  showsMade: number;
  hits: number;
  totalRevenue: number;
  bestScore: number;
  staff: Staff[];
  candidates: Staff[];
  research: string[];
  genresUnlocked: GenreId[];
  mediumsUnlocked: string[];
  comboLevels: Record<string, number>;
  franchises: Record<string, Franchise>;
  pendingSequel: string | null;
  contracts: Contract[];
  hallOfFame: HofEntry[];
  lastResult: ShowResult | null;
  lastDraft: Draft | null;
  bailouts: number;
  notices: string[];
  awardsYear: number;
  awards: number;
}

export const MAX_WEEKS = 48 * 6; // six-year career
export const START_CASH = 90_000;

export function initialRun(studio: string, showrunner: string): RunState {
  return {
    studio,
    showrunner,
    cash: START_CASH,
    fans: 0,
    rd: 12,
    week: 0,
    officeLevel: 0,
    showsMade: 0,
    hits: 0,
    totalRevenue: 0,
    bestScore: 0,
    staff: [],
    candidates: [rollCandidate(0), rollCandidate(0), rollCandidate(0)],
    research: [],
    genresUnlocked: ["shonen", "shojo", "slice", "fantasy"],
    mediumsUnlocked: ["tv", "ona"],
    comboLevels: {},
    franchises: {},
    pendingSequel: null,
    contracts: [rollContract(0), rollContract(0), rollContract(0)],
    hallOfFame: [],
    lastResult: null,
    lastDraft: null,
    bailouts: 0,
    notices: ["The industry is watching, rookie."],
    awardsYear: 1,
    awards: 0,
  };
}

export const office = (r: RunState) => OFFICES[r.officeLevel];
export const weeklyOutgoings = (r: RunState) =>
  office(r).rent + r.staff.reduce((a, s) => a + s.salary, 0);

/** Advance the calendar, charging wages + rent at each month end (Game Dev Story payday). */
export function advanceWeeks(r: RunState, n: number): RunState {
  let cash = r.cash;
  const notices = [...r.notices];
  let contracts = r.contracts;
  const perWeek = weeklyOutgoings(r);
  for (let i = 1; i <= n; i++) {
    const w = r.week + i;
    if (w % 4 === 0) {
      const bill = perWeek * 4;
      cash -= bill;
      notices.push(`Payday: wages + rent −£${bill.toLocaleString("en-GB")}.`);
    }
    if (w % 6 === 0) contracts = [rollContract(w), rollContract(w), rollContract(w)];
  }
  return {
    ...r,
    week: r.week + n,
    cash,
    contracts,
    staff: r.staff.map((s) => ({ ...s, stamina: Math.min(100, s.stamina + n * 9) })),
    notices: notices.slice(-40),
  };
}

export function studioScore(r: RunState): number {
  return Math.round(
    r.fans * 1.5 +
      r.totalRevenue / 400 +
      r.hallOfFame.length * 2200 +
      r.hits * 700 +
      r.showsMade * 200 +
      r.awards * 3000
  );
}
